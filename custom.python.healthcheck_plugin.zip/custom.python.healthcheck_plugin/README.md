# Dynatrace OneAgent Plugin

Simple Dynatrace OneAgent Host plugin for collecting session count using
- who command (Linux)
- quser command (Windows)